---
name: Sovereign Alpine Sanctuary
colors:
  surface: '#0b151a'
  surface-dim: '#0b151a'
  surface-bright: '#303b40'
  surface-container-lowest: '#060f14'
  surface-container-low: '#131d22'
  surface-container: '#172126'
  surface-container-high: '#212b31'
  surface-container-highest: '#2c363c'
  on-surface: '#d9e4eb'
  on-surface-variant: '#d1c5b4'
  inverse-surface: '#d9e4eb'
  inverse-on-surface: '#283237'
  outline: '#9a8f80'
  outline-variant: '#4e4639'
  surface-tint: '#e9c176'
  primary: '#e9c176'
  on-primary: '#412d00'
  primary-container: '#c7a15a'
  on-primary-container: '#503800'
  inverse-primary: '#785919'
  secondary: '#9ccee6'
  on-secondary: '#003546'
  secondary-container: '#174f64'
  on-secondary-container: '#8ebfd8'
  tertiary: '#e1c381'
  on-tertiary: '#3f2e00'
  tertiary-container: '#bfa364'
  on-tertiary-container: '#4c3903'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea6'
  primary-fixed-dim: '#e9c176'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5d4201'
  secondary-fixed: '#bee9ff'
  secondary-fixed-dim: '#9ccee6'
  on-secondary-fixed: '#001f2a'
  on-secondary-fixed-variant: '#144c61'
  tertiary-fixed: '#fedf9b'
  tertiary-fixed-dim: '#e1c381'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#58440e'
  background: '#0b151a'
  on-background: '#d9e4eb'
  surface-variant: '#2c363c'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '400'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 44px
    fontWeight: '500'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '500'
    lineHeight: 38px
    letterSpacing: 0em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0.01em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '300'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.22em
  label-caps-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.25em
  label-regular:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
spacing:
  unit-2xs: 0.25rem
  unit-xs: 0.5rem
  unit-sm: 0.75rem
  unit-md: 1rem
  unit-lg: 1.5rem
  unit-xl: 2rem
  unit-2xl: 3rem
  unit-3xl: 4rem
  unit-4xl: 6rem
  unit-5xl: 8rem
  gutter-desktop: 2.5rem
  gutter-mobile: 1.25rem
  container-max: 1440px
---

## Brand & Style

This design system embodies the pinnacle of restrained luxury, high-altitude sanctuary living, and private enclave exclusivity. Drawing directly from the heritage of the majestic mountain markhor and pristine alpine retreats, it merges timeless architectural grandeur with modern digital refinement. 

The aesthetic is characterized by:
- **Restrained Editorial Luxury:** Generous negative space, editorial pacing, and uncompromising typography that whispers prestige rather than shouting.
- **Architectural Precision:** Subtle hairline separators, micro-details, and asymmetric luxury grids reminiscent of architectural estate blueprints and high-end monographs.
- **Atmospheric Nocturne:** A nocturnal foundation rooted in abyssal alpine tones (midnight obsidian, deep fjord navy) balanced with warm champagne warmth, brushed gold embellishments, and crystalline water accents.
- **Noble Heritage:** Honoring the organic power and poise of alpine landscapes, conveying permanence, generational wealth, and discrete membership privileges.

## Colors

The palette is engineered around dark, moody elegance with warm metallic warmth and crisp glacial highlights.

- **Primary (`#C7A15A` - Luxury Gold):** Applied to primary actions, key architectural focal points, brand emblems, and active status indicators.
- **Secondary (`#164E63` - Water Blue):** Evoking glacial alpine tarns and high-altitude lakes; reserved for tranquil accents, verified badge indicators, and atmospheric glows.
- **Tertiary (`#D6B978` - Champagne):** A soft, luminous gold for delicate hairline borders, secondary metadata, and subtle hover states.
- **Neutral Core (`#071116` - Deep Midnight):** The foundational ground surface, evoking obsidian night skies and granite peaks.
- **Surface Elevation (`#0B1C26` - Deep Navy):** Layered containers, floating panels, and elevated modular cards.
- **Editorial Contrast (`#F4F0E8` - Warm Ivory):** High-contrast typography and iconography ensuring immaculate legibility without the harshness of pure white.

## Typography

The typography pairing contrasts the dramatic haute-couture rhythm of Playfair Display with the clean geometric discipline of Plus Jakarta Sans.

- **Headlines & Display:** Playfair Display introduces literary authority and sovereign character. Tracking is intentionally tightened at immense scales and eased slightly for smaller subheads. Italicised variants may be applied to selective single words within hero titles to create editorial pacing.
- **Body & Longform:** Plus Jakarta Sans is set in lighter weights (300 to 400) to maintain crisp breathability across dark backdrops, preventing visual weight buildup.
- **Labels & Micro-Copy:** Capitalized tracking (+0.22em to +0.25em) provides an authoritative, gallery-curated feel for architectural stats, lot sizes, membership categories, and geographic coordinates.

## Layout & Spacing

The layout is governed by an asymmetric 12-column architectural grid, prioritizing sweeping vistas, generous margin expanses, and deliberate spatial restraint.

- **Grid Architecture:** 12-column layout with a 1440px max-width container. Desktop gutters are fixed at `2.5rem`, tightening to `1.25rem` on mobile devices.
- **Whitespace Cadence:** Vertical rhythm leans deliberately unhurried. Estate showcases, architectural floor plans, and signature amenities demand `unit-4xl` to `unit-5xl` separation between thematic sections.
- **Reflow & Breakpoints:**
  - **Desktop (1280px+):** Asymmetrical magazine-style spreads, overlapping images with thin gold bordering, floating coordinate labels.
  - **Tablet (768px - 1279px):** Balanced 6-column reflow, sidebars collapse into bespoke full-screen navigation overlays.
  - **Mobile (< 768px):** Strict 4-column flow, edge-to-edge imagery with inset hairline frames, docked navigation controls.

## Elevation & Depth

Visual hierarchy does not rely on harsh drop shadows. Instead, it utilizes translucent depth, tonal gradation, and luminous hairline borders.

- **Hairline Framing:** Depth is defined by ultra-fine `1px` borders in semi-transparent metallic gold (`rgba(199, 161, 90, 0.22)`) or deep water blue (`rgba(22, 78, 99, 0.35)`).
- **Tonal Layers:** 
  - *Base Surface:* `#071116` (Deep Midnight)
  - *Layer 1 (Card & Module Ground):* `#0B1C26` (Deep Navy)
  - *Layer 2 (Floating Modals & Flyouts):* `#0E2330` with `backdrop-filter: blur(16px)`
- **Atmospheric Glows:** Soft, diffused ambient illumination is used sparingly behind focal assets (such as the markhor crest or featured mountain villa renderings). Shadows use `0 24px 48px -12px rgba(0, 0, 0, 0.65)` with an ethereal secondary halo: `0 0 40px -10px rgba(199, 161, 90, 0.12)`.

## Shapes

The design system embraces a **Sharp (`0`)** shape language, echoing timeless stone-carved architecture, precision drafting, and bespoke luxury packaging.

- **Corner Radii:** Zero radii (`0px`) on all core containers, buttons, image frames, and input fields. Sharp right angles project permanence, structural discipline, and architectural clarity.
- **Sub-Element Accents:** Subtle chamfers (45-degree micro-notches) may be applied exclusively to corner accents of hero cards or collectible membership credentials.
- **Iconography & Badges:** Geometric, razor-sharp forms framed in circular or diamond hairline wireframes.

## Components

### Buttons
- **Primary (Sovereign Gold):** Solid `#C7A15A` fill with `#071116` text, tracked uppercase typography (`label-caps-lg`), sharp corners (`0px`). On hover, smooth transition to `#D6B978` with a fine external ring glow (`box-shadow: 0 0 20px rgba(199, 161, 90, 0.3)`).
- **Secondary (Hairline Gold):** Transparent background, `1px solid #C7A15A`, `#F4F0E8` text. Hover fills the background with `rgba(199, 161, 90, 0.1)`.
- **Tertiary / Glacial Link:** `#164E63` border with `#F4F0E8` text and an inline arrow glyph with a sliding right transition on hover.

### Cards & Estate Modules
- **Container:** Grounded in `#0B1C26` surrounded by a `1px` border of `rgba(199, 161, 90, 0.2)`. 
- **Image Framing:** High-contrast landscape photography rendered edge-to-edge or held within a `12px` interior matting frame reminiscent of gallery art framing.
- **Badge Indicators:** Monospaced or uppercase labels floating top-right (e.g., "PRIVATE RESIDENCE", "OFF-MARKET") set against blurred obsidian backdrops.

### Input Fields & Selectors
- **Structure:** Clean bottom-bordered underline or complete 1px rectangular enclosure in `#0B1C26`. Border color rests at `rgba(214, 185, 120, 0.25)`.
- **Active / Focus:** Border transitions to pure `#C7A15A` with zero outer offset. Floating labels utilize `label-caps-sm` in `#D6B978`.
- **Placeholder:** Subdued `#F4F0E8` at 40% opacity in `body-md`.

### Chips & Metadata Tags
- **Appearance:** Low-profile rectangular pills with `0px` radius, bordered in `1px rgba(244, 240, 232, 0.15)`.
- **Text:** Set in `label-caps-sm` with `#F4F0E8` text and gold separator dots (`•`).

### Checkboxes & Radios
- **Design:** Geometric squares (`0px` radius) with `1px solid rgba(199, 161, 90, 0.4)`. Checked state displays a solid gold fill with an obsidian geometric mark.

### Bespoke Member Components
- **Private Key / Crest Badge:** A circular or diamond geometric emblem featuring the markhor icon, accented with concentric hairline rings.
- **Concierge Drawer:** Full-height slide-out navigation clad in `#071116` featuring gilded dividing rules and direct liaison contact modules.